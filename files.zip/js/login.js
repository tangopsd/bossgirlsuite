// Handles login and nickname storage

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById('loginForm');
  const email = document.getElementById('email');
  const password = document.getElementById('password');
  const nickname = document.getElementById('nickname');
  const errorMsg = document.getElementById('errorMsg');

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    // Clear errors
    errorMsg.style.display = "none";
    errorMsg.textContent = "";

    // Validate all fields are filled
    if (!email.value.trim() || !password.value.trim() || !nickname.value.trim()) {
      errorMsg.textContent = "Please fill in all fields.";
      errorMsg.style.display = "block";
      return;
    }

    // Save nickname to localStorage
    localStorage.setItem("userNickname", nickname.value.trim());

    // Redirect to landing.html (splash screen)
    window.location.href = "landing.html";
  });
});