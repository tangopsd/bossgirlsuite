// Photobooth functionality: webcam, capture, thumbnails, download

const video = document.getElementById('webcam');
const canvas = document.getElementById('canvas');
const captureBtn = document.getElementById('captureBtn');
const downloadBtn = document.getElementById('downloadBtn');
const thumbnailsPanel = document.getElementById('thumbnailsPanel');

let capturedPhotos = [];
let selectedPhotoIdx = null;

// ----- Webcam Access -----
async function startWebcam() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    video.srcObject = stream;
    video.play();
  } catch (err) {
    alert("Unable to access webcam. Please allow camera access.");
  }
}
startWebcam();

// ----- Capture Photo -----
captureBtn.addEventListener('click', function () {
  // Adjust canvas to video size
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const photoDataURL = canvas.toDataURL('image/png');
  // Add photo to start of array
  capturedPhotos.unshift(photoDataURL);
  // Only keep last 3 photos
  if (capturedPhotos.length > 3) capturedPhotos = capturedPhotos.slice(0, 3);
  selectedPhotoIdx = 0;
  renderThumbnails();
  downloadBtn.disabled = false;
});

// ----- Render Thumbnails -----
function renderThumbnails() {
  thumbnailsPanel.innerHTML = "";
  for (let i = 0; i < 3; ++i) {
    const frame = document.createElement('div');
    frame.className = "thumbnail-frame";
    if (capturedPhotos[i]) {
      const img = document.createElement('img');
      img.src = capturedPhotos[i];
      img.className = "thumb-img" + (i === selectedPhotoIdx ? " selected" : "");
      img.title = "Click to select";
      img.onclick = () => {
        selectedPhotoIdx = i;
        renderThumbnails();
        downloadBtn.disabled = false;
      };
      frame.appendChild(img);
    } else {
      // Insert SVG landscape for empty thumbnail
      const svg = document.getElementById("emptyThumbSVG").cloneNode(true);
      svg.removeAttribute("id");
      svg.classList.add("empty-thumb-img");
      svg.style.display = "block";
      frame.appendChild(svg);
    }
    thumbnailsPanel.appendChild(frame);
  }
}

// ----- Download Photo -----
downloadBtn.addEventListener('click', function () {
  if (capturedPhotos.length === 3) {
    // Create a photostrip: vertical strip of 3 images
    createPhotoStripAndDownload();
  } else if (selectedPhotoIdx !== null && capturedPhotos[selectedPhotoIdx]) {
    // Download selected single photo
    const a = document.createElement('a');
    a.href = capturedPhotos[selectedPhotoIdx];
    a.download = `bossgirl-photobooth-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
});

// ----- Create and Download Photo Strip -----
function createPhotoStripAndDownload() {
  // All images should be the same size as the webcam/canvas
  // We'll use the current canvas size, or fallback to 640x480
  let w = canvas.width || 640, h = canvas.height || 480;

  // Create a new canvas tall enough for 3 stacked images
  const stripCanvas = document.createElement('canvas');
  stripCanvas.width = w;
  stripCanvas.height = h * 3;

  const ctx = stripCanvas.getContext('2d');

  // Because drawImage with dataURL is async, wait for all images to load
  Promise.all(
    capturedPhotos.map((src) => {
      return new Promise((resolve) => {
        const img = new window.Image();
        img.onload = () => resolve(img);
        img.src = src;
      });
    })
  ).then((imgs) => {
    for (let i = 0; i < 3; ++i) {
      ctx.drawImage(imgs[2 - i], 0, h * i, w, h); // bottom is first taken, top is last taken
    }
    const stripDataURL = stripCanvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = stripDataURL;
    a.download = `bossgirl-photostrip-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  });
}

// Disable download if no photo
if (capturedPhotos.length === 0) downloadBtn.disabled = true;

// Floating nav events
document.getElementById("nav-home").onclick = () => window.location.href = "homepage.html";
document.getElementById("nav-photobooth").onclick = () => window.location.href = "photobooth.html";
document.getElementById("nav-journal").onclick = () => window.location.href = "journal.html";
document.getElementById("nav-todo").onclick = () => window.location.href = "todo.html";
document.getElementById("nav-spotify").onclick = () => window.location.href = "spotify.html";
document.getElementById("nav-float").onclick = () => window.location.href = "float.html";
document.getElementById("nav-heartchart").onclick = () => window.location.href = "heartchart.html";

// Initial render
renderThumbnails();