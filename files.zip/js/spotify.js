// Dummy controls for play/pause, skip, shuffle
const playPauseBtn = document.getElementById('playPauseBtn');
const playIcon = document.getElementById('playIcon');
const pauseIcon = document.getElementById('pauseIcon');
let isPlaying = false;

playPauseBtn.addEventListener('click', () => {
  isPlaying = !isPlaying;
  playIcon.style.display = isPlaying ? 'none' : '';
  pauseIcon.style.display = isPlaying ? '' : 'none';
  playPauseBtn.classList.toggle('active', isPlaying);
});

// Dummy: Progress bar animation
const progressBar = document.getElementById('progressBar');
const duration = 250; // seconds
let current = 0;
let fakeInterval = null;
function startProgress() {
  if (fakeInterval) clearInterval(fakeInterval);
  current = 0;
  updateProgress();
  fakeInterval = setInterval(() => {
    if (!isPlaying) return;
    current++;
    if (current > duration) {
      current = 0;
    }
    updateProgress();
  }, 1000);
}
function updateProgress() {
  document.getElementById('currentTime').textContent = toTime(current);
  document.getElementById('duration').textContent = toTime(duration);
  progressBar.style.width = (current / duration * 100) + "%";
}
function toTime(s) {
  const m = Math.floor(s / 60);
  const sec = String(s % 60).padStart(2, '0');
  return m + ':' + sec;
}
startProgress();

// Dummy next/skip/shuffle/repeat handlers
document.getElementById('nextBtn').onclick = document.getElementById('prevBtn').onclick = () => {
  // Simulate play next (reset progress)
  current = 0;
  updateProgress();
  // Simulate new song/album art
  simulateAlbumArtChange();
};
document.getElementById('shuffleBtn').onclick = () => alert("Shuffle (dummy)");
document.getElementById('repeatBtn').onclick = () => alert("Repeat (dummy)");

// Simulate album art change, extract dominant color, update gradient
function simulateAlbumArtChange() {
  // Example album arts, randomize
  const albumArts = [
    "https://i.scdn.co/image/ab67616d0000b273c4b6c0e9b3c0e76de941f7b3",
    "https://i.scdn.co/image/ab67616d0000b2732a7d9b7c0991b9a6b1b2211c",
    "https://i.scdn.co/image/ab67616d0000b273e06a7d7a5b0fda4a3b7b5f0b",
    "https://i.scdn.co/image/ab67616d0000b2736fbbf1e0e0e6f6b2c7f9b6b1",
    "https://i.scdn.co/image/ab67616d0000b273c3f6b4e6e5a4a3e1e7b8b7c1"
  ];
  const art = albumArts[Math.floor(Math.random() * albumArts.length)];
  updateGradientFromAlbumArt(art);
}
function updateGradientFromAlbumArt(url) {
  const img = new window.Image();
  img.crossOrigin = 'anonymous';
  img.src = url;
  img.onload = function () {
    const vibrant = new window.Vibrant(img);
    vibrant.getPalette().then(palette => {
      let color = palette.Vibrant ? palette.Vibrant.hex : "#a18cd1";
      // Animate gradient background
      document.body.style.transition = "background 1.1s cubic-bezier(.4,2,.4,1)";
      document.body.style.background = `linear-gradient(120deg, ${color} 0%, #fbc2eb 100%)`;
    });
  }
}
// On load, simulate first album art
simulateAlbumArtChange();

// Floating nav events
document.getElementById("nav-home").onclick = () => window.location.href = "homepage.html";
document.getElementById("nav-photobooth").onclick = () => window.location.href = "photobooth.html";
document.getElementById("nav-journal").onclick = () => window.location.href = "journal.html";
document.getElementById("nav-todo").onclick = () => window.location.href = "todo.html";
document.getElementById("nav-spotify").onclick = () => window.location.href = "spotify.html";
document.getElementById("nav-float").onclick = () => window.location.href = "float.html";
document.getElementById("nav-heartchart").onclick = () => window.location.href = "heartchart.html";