// Loads nickname, dynamic gradient, quote API, nav, and typing quote

const gradients = [
  {
    name: "hot-pink",
    class: "wave-hot-pink"
  },
  {
    name: "baby-pink",
    class: "wave-baby-pink"
  },
  {
    name: "hot-purple",
    class: "wave-hot-purple"
  },
  {
    name: "baby-purple",
    class: "wave-baby-purple"
  },
  {
    name: "hot-blue",
    class: "wave-hot-blue"
  },
  {
    name: "baby-blue",
    class: "wave-baby-blue"
  }
];

// Remove all wave gradient classes before applying a new one
function setGradient(themeName) {
  gradients.forEach(g => document.body.classList.remove(g.class));
  const theme = gradients.find(g => g.name === themeName);
  if (theme) {
    document.body.classList.add(theme.class);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  // Set animated gradient from localStorage, or default
  let themeName = localStorage.getItem("bgGradient") || "hot-pink";
  setGradient(themeName);

  // Hamburger menu for gradients
  const menuBtn = document.getElementById("menuBtn");
  const gradientMenu = document.getElementById("gradientMenu");
  let menuOpen = false;

  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    gradientMenu.style.display = menuOpen ? "none" : "flex";
    menuOpen = !menuOpen;
    // highlight current
    const options = gradientMenu.querySelectorAll(".gradient-option");
    options.forEach(btn => {
      btn.classList.toggle("active", btn.dataset.theme === (localStorage.getItem("bgGradient") || "hot-pink"));
      // Use a static color for preview, since animated gradient previews are not needed for dropdown
      btn.style.background = "rgba(255,255,255,0.71)";
      btn.style.color = "#181218";
    });
  });

  // Hide menu on click outside
  document.addEventListener("click", (e) => {
    if (menuOpen && !gradientMenu.contains(e.target) && e.target !== menuBtn) {
      gradientMenu.style.display = "none";
      menuOpen = false;
    }
  });

  // Gradient menu options
  document.querySelectorAll(".gradient-option").forEach(btn => {
    btn.addEventListener("click", () => {
      setGradient(btn.dataset.theme);
      localStorage.setItem("bgGradient", btn.dataset.theme);
      gradientMenu.style.display = "none";
      menuOpen = false;
    });
  });

  // Load nickname
  const nickname = localStorage.getItem("userNickname") || "BOSS";
  document.getElementById("nicknameSpan").textContent = nickname.toUpperCase();

  // Quote API + typewriter
  function typeWriterEffect(element, text, delay = 23) {
    element.textContent = "";
    let i = 0;
    function type() {
      if (i <= text.length) {
        element.textContent = text.slice(0, i);
        i++;
        setTimeout(type, delay);
      }
    }
    type();
  }

  // Always get a different quote using a cache buster
  function fetchQuote() {
    fetch("https://zenquotes.io/api/random?cb=" + Date.now())
      .then(r => r.json())
      .then(data => {
        let quote = "\"Stay inspired. Stay you.\"";
        if (data && data[0] && data[0].q) {
          quote = `"${data[0].q}"`;
        }
        typeWriterEffect(document.getElementById("quote"), quote, 22);
      })
      .catch(() => {
        typeWriterEffect(document.getElementById("quote"), "\"Stay inspired. Stay you.\"", 22);
      });
  }

  fetchQuote();

  // Floating nav events
  document.getElementById("nav-home").onclick = () => window.location.href = "homepage.html";
  document.getElementById("nav-photobooth").onclick = () => window.location.href = "photobooth.html";
  document.getElementById("nav-journal").onclick = () => window.location.href = "journal.html";
  document.getElementById("nav-todo").onclick = () => window.location.href = "todo.html";
  document.getElementById("nav-spotify").onclick = () => window.location.href = "spotify.html";
  document.getElementById("nav-float").onclick = () => window.location.href = "float.html";
  document.getElementById("nav-heartchart").onclick = () => window.location.href = "heartchart.html";
});