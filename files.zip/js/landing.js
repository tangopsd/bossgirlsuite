// Splash screen animation + redirect

setTimeout(function () {
  window.location.href = "homepage.html";
}, 3000);