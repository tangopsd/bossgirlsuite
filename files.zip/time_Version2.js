// time.js

const TIMER_PRESETS = [5, 10, 15, 20, 25, 30, 45, 60];

const timerPill = document.getElementById("timerPill");
const stopwatchPill = document.getElementById("stopwatchPill");
const timerSetRow = document.getElementById("timerSetRow");
const timerSetSelect = document.getElementById("timerSetSelect");
const timeDisplay = document.getElementById("timeDisplay");
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const resetBtn = document.getElementById("resetBtn");
const toggleIndicator = document.getElementById("toggleIndicator");
const tinkleAudio = document.getElementById("tinkleAudio");

let mode = "timer"; // or "stopwatch"
let timerSetting = 25 * 60; // in seconds, default 25 min
let remaining = timerSetting; // in seconds
let running = false;
let interval = null;
let stopwatch = 0;
let swRunning = false;

// ---- UI Helpers ----
function pad(num) {
  return num.toString().padStart(2, "0");
}
function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${pad(m)}:${pad(s)}`;
}
function updateDisplay() {
  if (mode === "timer") {
    timeDisplay.textContent = formatTime(remaining);
  } else {
    timeDisplay.textContent = formatTime(stopwatch);
  }
}
// ---- Pills ----
function switchMode(newMode) {
  if (interval) clearInterval(interval);
  running = false;
  swRunning = false;
  startBtn.disabled = false;
  stopBtn.disabled = false;
  if (newMode === "timer") {
    mode = "timer";
    timerPill.classList.add("active");
    stopwatchPill.classList.remove("active");
    timerSetRow.style.display = "";
    toggleIndicator.classList.remove("stopwatch");
    remaining = parseInt(timerSetSelect.value, 10) * 60;
    updateDisplay();
  } else {
    mode = "stopwatch";
    stopwatchPill.classList.add("active");
    timerPill.classList.remove("active");
    timerSetRow.style.display = "none";
    toggleIndicator.classList.add("stopwatch");
    updateDisplay();
  }
}
timerPill.onclick = () => switchMode("timer");
stopwatchPill.onclick = () => switchMode("stopwatch");

// ---- Timer preset ----
timerSetSelect.onchange = () => {
  timerSetting = parseInt(timerSetSelect.value, 10) * 60;
  remaining = timerSetting;
  updateDisplay();
};

// ---- Buttons ----
function startTimer() {
  if (mode === "timer") {
    if (remaining <= 0 || running) return;
    running = true;
    startBtn.disabled = true;
    stopBtn.disabled = false;
    interval = setInterval(() => {
      if (remaining <= 1) {
        remaining = 0;
        updateDisplay();
        clearInterval(interval);
        running = false;
        startBtn.disabled = false;
        stopBtn.disabled = true;
        tinkleAudio.currentTime = 0;
        tinkleAudio.play();
        return;
      }
      remaining--;
      updateDisplay();
    }, 1000);
  } else if (mode === "stopwatch") {
    if (swRunning) return;
    swRunning = true;
    startBtn.disabled = true;
    stopBtn.disabled = false;
    interval = setInterval(() => {
      stopwatch++;
      updateDisplay();
    }, 1000);
  }
}
function stopTimer() {
  if (interval) clearInterval(interval);
  if (mode === "timer") {
    running = false;
    startBtn.disabled = false;
    stopBtn.disabled = true;
  } else if (mode === "stopwatch") {
    swRunning = false;
    startBtn.disabled = false;
    stopBtn.disabled = true;
  }
}
function resetTimer() {
  if (interval) clearInterval(interval);
  if (mode === "timer") {
    running = false;
    remaining = parseInt(timerSetSelect.value, 10) * 60;
    updateDisplay();
    startBtn.disabled = false;
    stopBtn.disabled = false;
  } else if (mode === "stopwatch") {
    swRunning = false;
    stopwatch = 0;
    updateDisplay();
    startBtn.disabled = false;
    stopBtn.disabled = false;
  }
}
startBtn.onclick = startTimer;
stopBtn.onclick = stopTimer;
resetBtn.onclick = resetTimer;

// ---- Initial State ----
updateDisplay();
stopBtn.disabled = true;